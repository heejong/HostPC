var searchData=
[
  ['quit',['Quit',['../_u_i___common_8c.html#a0863fae09b2ecd7adb9c7ccd2f3aa38b',1,'Quit(int panel, int control, int event, void *callbackData, int eventData1, int eventData2):&#160;UI_Common.c'],['../_u_i___common_8h.html#a0863fae09b2ecd7adb9c7ccd2f3aa38b',1,'Quit(int panel, int control, int event, void *callbackData, int eventData1, int eventData2):&#160;UI_Common.c']]]
];
